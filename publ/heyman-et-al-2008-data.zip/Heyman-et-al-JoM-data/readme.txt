These shape (and associated) files contain the original data for the following map:

HEYMAN, J., H�TTESTRAND, C. and STROEVEN A.P. (2008) Glacial geomorphology of the Bayan Har sector of the NE Tibetan Plateau. Journal of Maps.
(available from http://www.journalofmaps.com/)


Projected coordinate system: UTM zone 47N
Map datum: WGS 1984


For further info: jakob.heyman@natgeo.su.se