% Wrapper script for 10Be and 26Al exposure age calculator.
% Read and fix input, use get_al_be_age to calculate exposure ages, and fix and write output.
% Jakob Heyman - 2015-2016

clear all;

tic();

% read input file
[samplein.sample_name,samplein.lat,samplein.long,samplein.elv,samplein.aa,samplein.thick,samplein.rho,samplein.othercorr,samplein.E,samplein.N10,samplein.delN10,samplein.be_stds,samplein.N26,samplein.delN26,samplein.al_stds,samplein.samplingyr] = textread('input.txt','%s %n %n %n %s %n %n %n %n %n %n %s %n %n %s %n');

% fix strings in input
samplein.sample_name = strvcat(samplein.sample_name);
samplein.aa = strvcat(samplein.aa);
samplein.be_stds = strvcat(samplein.be_stds);
samplein.al_stds = strvcat(samplein.al_stds);

% run and load al_be constants
make_al_be_consts_v1;
load al_be_consts_v1;

% make consts_LSD
make_consts_LSD;

% convert 10Be concentrations according to standards
for i = 1:numel(samplein.N10);
	be_mult(i,1) = al_be_consts.be_stds_cfs(strmatch(samplein.be_stds(i,:),al_be_consts.be_stds_names,'exact'));
end;

samplein.N10 = samplein.N10 .* be_mult;
samplein.delN10 = samplein.delN10 .* be_mult;

% convert 26Al concentrations according to standards
for i = 1:numel(samplein.N26);
	al_mult(i,1) = al_be_consts.al_stds_cfs(strmatch(samplein.al_stds(i,:),al_be_consts.al_stds_names,'exact'));
end;

samplein.N26 = samplein.N26 .* al_mult;
samplein.delN26 = samplein.delN26 .* al_mult;

% pick out samples one by one
for i = 1:numel(samplein.lat);
	i
	sample.sample_name = samplein.sample_name(i,:);
	sample.lat = samplein.lat(i);
	sample.long = samplein.long(i);
	sample.elv = samplein.elv(i);
	sample.aa = samplein.aa(i,:);
	sample.thick = samplein.thick(i);
	sample.rho = samplein.rho(i);
	sample.othercorr = samplein.othercorr(i);
	sample.E = samplein.E(i);
	sample.N10 = samplein.N10(i);
	sample.delN10 = samplein.delN10(i);
	sample.be_stds = samplein.be_stds(i,:);
	sample.N26 = samplein.N26(i);
	sample.delN26 = samplein.delN26(i);
	sample.al_stds = samplein.al_stds(i,:);
	sample.samplingyr = samplein.samplingyr(i);
	
	if (strcmp(sample.aa,'std'));
		sample.pressure = ERA40atm(sample.lat,sample.long,sample.elv);
	elseif (strcmp(sample.aa,'ant'));
		sample.pressure = antatm(sample.elv);
	elseif (strcmp(sample.aa,'pre'));
		sample.pressure = sample.elv;
	end;
	
	% calculate ages
	if (sample.N10 + sample.delN10) > 0;
		results10 = get_al_be_age(sample,al_be_consts,10);
		
		output10(i,1) = results10.t_nu;
		output10(i,2) = results10.delt_ext_nu;
		output10(i,3) = results10.delt_int_nu;
	%	output10(i,4) = results10.t_sp;
	%	output10(i,5) = results10.delt_ext_sp;
	%	output10(i,6) = results10.delt_int_sp;
	end;
	
	if (sample.N26 + sample.delN26) > 0;
		results26 = get_al_be_age(sample,al_be_consts,26);
		
		output26(i,1) = results26.t_nu;
		output26(i,2) = results26.delt_ext_nu;
		output26(i,3) = results26.delt_int_nu;
	%	output26(i,4) = results26.t_sp;
	%	output26(i,5) = results26.delt_ext_sp;
	%	output26(i,6) = results26.delt_int_sp;
	end;
	
	clear sample;
end;

% if any 10Be: fix and save expages10.txt
if sum(samplein.N10 + samplein.delN10)>0;
	if numel(output10(:,1))<numel(samplein.N10);
	%	output10(numel(samplein.N10),6) = 0;
		output10(numel(samplein.N10),3) = 0;
	end;
	
	nanmatr = output10>0;
	output10 = output10.*nanmatr./nanmatr;
	
	out10 = fopen('expages10.txt','w');
	dlmwrite('expages10.txt',output10,'delimiter','\t','precision','%.0f');
	fclose(out10);
end;

% if any 26Al: fix and save expages26.txt
if sum(samplein.N26 + samplein.delN26)>0;
	if numel(output26(:,1))<numel(samplein.N26);
	%	output26(numel(samplein.N26),6) = 0;
		output26(numel(samplein.N26),3) = 0;
	end;
	
	nanmatr = output26>0;
	output26 = output26.*nanmatr./nanmatr;
	
	out26 = fopen('expages26.txt','w');
	dlmwrite('expages26.txt',output26,'delimiter','\t','precision','%.0f');
	fclose(out26);
end;

toc()
